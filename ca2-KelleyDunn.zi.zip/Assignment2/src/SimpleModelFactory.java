import java.util.*;

/**
 *
 * @author David Kelley
 */
public abstract class SimpleModelFactory {
    public abstract ArrayList<Double> evaluate(String func, ArrayList<Double> values);
}
